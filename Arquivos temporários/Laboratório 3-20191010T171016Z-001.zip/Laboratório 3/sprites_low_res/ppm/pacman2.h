#ifndef PACMAN2_H
#define PACMAN2_H

extern const unsigned long pacman2_termination;
extern const unsigned long pacman2_start;
extern const unsigned long pacman2_finish;
extern const unsigned long pacman2_length;
extern const unsigned char pacman2[];

#endif /* PACMAN2_H */
