#ifndef EYES_H
#define EYES_H

extern const unsigned long eyes_termination;
extern const unsigned long eyes_start;
extern const unsigned long eyes_finish;
extern const unsigned long eyes_length;
extern const unsigned char eyes[];

#endif /* EYES_H */
