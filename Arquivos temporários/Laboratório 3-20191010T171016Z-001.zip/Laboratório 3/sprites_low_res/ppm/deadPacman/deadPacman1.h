#ifndef DEADPACMAN1_H
#define DEADPACMAN1_H

extern const unsigned long deadPacman1_termination;
extern const unsigned long deadPacman1_start;
extern const unsigned long deadPacman1_finish;
extern const unsigned long deadPacman1_length;
extern const unsigned char deadPacman1[];

#endif /* DEADPACMAN1_H */
