
#ifndef __BUTTONS_H__
#define __BUTTONS_H__

extern void button_init();
extern bool button_read_s1();
extern bool button_read_s2();

#endif //__BUTTONS_H
