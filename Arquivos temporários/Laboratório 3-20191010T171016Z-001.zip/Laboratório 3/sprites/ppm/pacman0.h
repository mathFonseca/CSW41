#ifndef PACMAN0_H
#define PACMAN0_H

extern const unsigned long pacman0_termination;
extern const unsigned long pacman0_start;
extern const unsigned long pacman0_finish;
extern const unsigned long pacman0_length;
extern const unsigned char pacman0[];

#endif /* PACMAN0_H */
