#include "draw.h"

int32_t pos_teste; // Localiza o pacman na memoria
