#ifndef DEADPACMAN4_H
#define DEADPACMAN4_H

extern const unsigned long deadPacman4_termination;
extern const unsigned long deadPacman4_start;
extern const unsigned long deadPacman4_finish;
extern const unsigned long deadPacman4_length;
extern const unsigned char deadPacman4[];

#endif /* DEADPACMAN4_H */
