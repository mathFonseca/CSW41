#ifndef VITAMINA_H
#define VITAMINA_H

extern const unsigned long vitamina_termination;
extern const unsigned long vitamina_start;
extern const unsigned long vitamina_finish;
extern const unsigned long vitamina_length;
extern const unsigned char vitamina[];

#endif /* VITAMINA_H */
