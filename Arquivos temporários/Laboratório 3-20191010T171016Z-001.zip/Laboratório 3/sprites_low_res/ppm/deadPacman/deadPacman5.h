#ifndef DEADPACMAN5_H
#define DEADPACMAN5_H

extern const unsigned long deadPacman5_termination;
extern const unsigned long deadPacman5_start;
extern const unsigned long deadPacman5_finish;
extern const unsigned long deadPacman5_length;
extern const unsigned char deadPacman5[];

#endif /* DEADPACMAN5_H */
