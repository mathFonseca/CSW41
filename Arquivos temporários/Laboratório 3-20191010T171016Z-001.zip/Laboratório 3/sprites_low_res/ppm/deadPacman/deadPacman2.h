#ifndef DEADPACMAN2_H
#define DEADPACMAN2_H

extern const unsigned long deadPacman2_termination;
extern const unsigned long deadPacman2_start;
extern const unsigned long deadPacman2_finish;
extern const unsigned long deadPacman2_length;
extern const unsigned char deadPacman2[];

#endif /* DEADPACMAN2_H */
