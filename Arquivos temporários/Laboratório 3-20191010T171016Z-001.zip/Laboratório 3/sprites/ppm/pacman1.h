#ifndef PACMAN1_H
#define PACMAN1_H

extern const unsigned long pacman1_termination;
extern const unsigned long pacman1_start;
extern const unsigned long pacman1_finish;
extern const unsigned long pacman1_length;
extern const unsigned char pacman1[];

#endif /* PACMAN1_H */
