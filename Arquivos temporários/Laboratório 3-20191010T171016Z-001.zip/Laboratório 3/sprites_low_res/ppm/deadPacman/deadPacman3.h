#ifndef DEADPACMAN3_H
#define DEADPACMAN3_H

extern const unsigned long deadPacman3_termination;
extern const unsigned long deadPacman3_start;
extern const unsigned long deadPacman3_finish;
extern const unsigned long deadPacman3_length;
extern const unsigned char deadPacman3[];

#endif /* DEADPACMAN3_H */
