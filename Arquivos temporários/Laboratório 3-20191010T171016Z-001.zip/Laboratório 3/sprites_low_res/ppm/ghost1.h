#ifndef GHOST1_H
#define GHOST1_H

extern const unsigned long ghost1_termination;
extern const unsigned long ghost1_start;
extern const unsigned long ghost1_finish;
extern const unsigned long ghost1_length;
extern const unsigned char ghost1[];

#endif /* GHOST1_H */
