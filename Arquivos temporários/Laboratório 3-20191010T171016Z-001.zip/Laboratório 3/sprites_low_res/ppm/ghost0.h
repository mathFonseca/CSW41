#ifndef GHOST0_H
#define GHOST0_H

extern const unsigned long ghost0_termination;
extern const unsigned long ghost0_start;
extern const unsigned long ghost0_finish;
extern const unsigned long ghost0_length;
extern const unsigned char ghost0[];

#endif /* GHOST0_H */
