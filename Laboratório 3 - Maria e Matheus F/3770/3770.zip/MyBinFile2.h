#ifndef MYBINFILE2_H
#define MYBINFILE2_H

extern const unsigned long MyBinaryImage2_termination;
extern const unsigned long MyBinaryImage2_start;
extern const unsigned long MyBinaryImage2_finish;
extern const unsigned long MyBinaryImage2_length;
extern const unsigned char MyBinaryImage2[];

#endif /* MYBINFILE2_H */
