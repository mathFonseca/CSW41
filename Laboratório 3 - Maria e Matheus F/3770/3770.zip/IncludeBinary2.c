
const unsigned char MyBinaryImage2[] = {
#include "MyBinFile1.inc"
};

